runModel  = function(param, names, ...) {

# set parameter names
names(param) = names

# writes the calibrated parameters into a CSV file
# following Osmose format. The parameters in this file
# will overwrite the Osmose parameter
write.table(param, file="calibration-parameters.csv", sep=";", 
            col.names=FALSE, quote=FALSE)

# defines the user directory
outdir = "output_temp"

cat("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ ", getwd(), "\n")

# run Osmose Model
run_osmose(input="calib_config.csv", verbose=TRUE, clean=TRUE) 

data = read_osmose(path=outdir)

# extract the biomass and yields variables (monthly data).
# expectes = TRUE to average over the replicates
osmose.biomass = getVar(data, "biomass", expected=TRUE)
osmose.thresholds = getVar(data, "biomass", expected=TRUE)
osmose.yields = getVar(data, "yield", expected=TRUE)

# define a year factor for yearly integration of biomass
# from monthly biomass
biomassDim = dim(osmose.biomass)   # dims=(time, species, replic)
ntime = biomassDim[1]    # nyears * 12
nspecies = biomassDim[2]
nyears = ntime / 12
years = factor(rep(1:nyears, each=12))

# Integration of monthly values into yearly values
# here, tapply is applied on dimension 1 (i.e. time)

osmose.yields = apply(osmose.yields, 2, tapply, years, sum)

output = list(# Biomass
  EngraulisEncrasicolus.biomass       = param["q.sp0"]*osmose.biomass[, "EngraulisEncrasicolus"],
  SprattusSprattus.biomass            = param["q.sp1"]*osmose.biomass[, "SprattusSprattus"],
  TrachurusMediterraneaus.biomass     = param["q.sp2"]*osmose.biomass[, "TrachurusMediterraneaus"],
  MullusBarbatus.biomass              = param["q.sp3"]*osmose.biomass[, "MullusBarbatus"],
  MerlangiusMerlangus.biomass         = param["q.sp4"]*osmose.biomass[, "MerlangiusMerlangus"],
  PsettaMaximaMaeotica.biomass        = param["q.sp5"]*osmose.biomass[, "PsettaMaximaMaeotica"],
  PomatomusSaltatrix.biomass          = param["q.sp6"]*osmose.biomass[, "PomatomusSaltatrix"],
  SardaSarda.biomass                  = param["q.sp7"]*osmose.biomass[, "SardaSarda"],)
  
return(output)
}
